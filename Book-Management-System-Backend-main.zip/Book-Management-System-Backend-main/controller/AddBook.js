const Books = require("../model/Book");
const AddBook = async (req, res) => {
  try {
    
    const Bookdetail = await new Books(req.body);
    await Bookdetail.save();
    return res.json({
      data: Bookdetail,
      message: "book Added successfully",
      success: true,
      error: false,
    });
  } catch (error) {
     return res.json({
      message: error.message || error,
      success: false,
      error: true,
    });
  }
};
module.exports = AddBook;
