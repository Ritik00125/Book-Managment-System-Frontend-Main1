const Books = require("../model/Book");

// Controller function to get all books
const GetallBooks = async (req, res) => {
  try {
    const allBooks = await Books.find({});
    const countBooks = await Books.countDocuments();

    return res.json({
      data: allBooks,
      totalDocument : countBooks,
      success: true,
      error: false,
      message: "Books fetched successfully",
    });
  } catch (error) {
    return res.status(500).json({
      message: error.message || "Internal Server Error",
      success: false,
      error: true,
    });
  }
};

module.exports = GetallBooks;
