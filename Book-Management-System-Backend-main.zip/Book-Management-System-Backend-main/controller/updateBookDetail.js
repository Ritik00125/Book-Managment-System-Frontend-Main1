const Books = require("../model/Book");

const updateBookDetail = async (req, res) => {
  try {
    const { id } = req.params;
 

    const updatedBook = await Books.findByIdAndUpdate(id, req.body, {
      new: true,         // returns the updated document
      runValidators: true // applies schema validation
    });

    if (!updatedBook) {
      return res.status(404).json({
        message: "Book not found",
        success: false,
        error: true,
      });
    }

    return res.status(200).json({
      message: "Book detail updated successfully",
      success: true,
      error: false,
      data: updatedBook
    });
  } catch (error) {
    return res.status(500).json({
      message: error.message || "Internal Server Error",
      success: false,
      error: true,
    });
  }
};

module.exports = updateBookDetail;
