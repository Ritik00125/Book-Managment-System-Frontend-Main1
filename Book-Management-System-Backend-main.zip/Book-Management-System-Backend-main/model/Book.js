const mongoose = require("mongoose");

// Define the schema
const BookSchema = new mongoose.Schema({

  name: {
    type: String,
    required: true,
    trim: true
  },
  author: {
    type: String,
    required: true,
    trim: true
  },
  edition: {
    type: String,
    trim: true
  },
  price: {
    type: Number,
    required: true
  },
  pages: {
    type: Number,
    required: true
  },
  description: {
    type: String,
    trim: true
  }
});

// Create and export model
const Book = mongoose.model("Book", BookSchema);
module.exports = Book;
