const express = require("express");
const mongoose = require("mongoose");
const router = require("./routes/BookRouter")

const cors = require("cors");
const bodyParser = require("body-parser");
require('dotenv').config({debug : false});

// mongo db connection 
mongoose.set("strictQuery" , false);
mongoose.Promise = global.Promise;

const app = express();
app.use(express.json());

//non blocking from the origin
app.use(cors({
  origin : "*",
  credentials : false
}))

app.get("/" , (req , res)=>{
  res.json({
    name : "shamshad Ahamad"
  })
})

//using router
app.use("/" , router);



if(!process.env.MONGO_URI){
  throw new Error("MONGO_URI is not defined in .env");
}
mongoose.connect(process.env.MONGO_URI).then(()=>{
  console.log("Mongodb connected successfully")
}).then(()=>{
  app.listen(process.env.PORT , ()=>{
    console.log(`server is connected on ${process.env.URL}:${process.env.PORT}`)
  })
})

