import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";
import { FaBook, FaUserEdit, FaMoneyBillWave, FaFileAlt, FaPlusCircle } from "react-icons/fa";
import { motion } from "framer-motion";
import "animate.css/animate.min.css";

const AddBook = () => {
  const navigate = useNavigate();
  const [book, setBook] = useState({
    name: "",
    author: "",
    edition: "",
    price: "",
    pages: "",
    description: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setBook((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      await axios.post("http://localhost:4000/books", book);
      await Swal.fire({
        title: 'Success!',
        text: 'Book added successfully!',
        icon: 'success',
        confirmButtonText: 'OK',
        background: '#f8f9fa',
        backdrop: `
          rgba(0,0,123,0.4)
          url("/images/nyan-cat.gif")
          left top
          no-repeat
        `
      });
      navigate("/book-list");
    } catch (error) {
      console.log(error);
      Swal.fire({
        title: 'Error!',
        text: 'Failed to add book. Please try again.',
        icon: 'error',
        confirmButtonText: 'OK',
        background: '#f8f9fa'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { type: "spring", stiffness: 100 }
    }
  };

  return (
    <div className="container py-5">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="row justify-content-center"
      >
        <div className="col-lg-8 col-md-10">
          <div className="card border-0 shadow-lg rounded-4 overflow-hidden">
            <div className="card-header bg-gradient-primary text-white py-4">
              <div className="d-flex align-items-center">
                <FaBook className="fs-1 me-3"  style={{color : "black"}}/>
                <div style={{color: "blue"}}>
                  <h2 className="mb-0 fw-bold">Add New Book</h2>
                  <p className="mb-0 opacity-75">Fill in the book details below</p>
                </div>
              </div>
            </div>

            <div className="card-body p-4 p-md-5">
              <motion.form
                onSubmit={handleSubmit}
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                {/* Book Name */}
                <motion.div variants={itemVariants} className="mb-4">
                  <label className="form-label fw-semibold">
                    <FaBook className="me-2" />
                    Book Name
                  </label>
                  <input
                    type="text"
                    className="form-control form-control-lg border-2 py-3"
                    name="name"
                    value={book.name}
                    onChange={handleChange}
                    placeholder="Enter book title"
                    required
                  />
                </motion.div>

                {/* Author Name */}
                <motion.div variants={itemVariants} className="mb-4">
                  <label className="form-label fw-semibold">
                    <FaUserEdit className="me-2" />
                    Author Name
                  </label>
                  <input
                    type="text"
                    className="form-control form-control-lg border-2 py-3"
                    name="author"
                    value={book.author}
                    onChange={handleChange}
                    placeholder="Enter author name"
                    required
                  />
                </motion.div>

                <div className="row">
                  {/* Edition */}
                  <motion.div variants={itemVariants} className="col-md-6 mb-4">
                    <label className="form-label fw-semibold">
                      <FaFileAlt className="me-2" />
                      Edition
                    </label>
                    <input
                      type="text"
                      className="form-control form-control-lg border-2 py-3"
                      name="edition"
                      value={book.edition}
                      onChange={handleChange}
                      placeholder="e.g., 1st Edition"
                      required
                    />
                  </motion.div>

                  {/* Price */}
                  <motion.div variants={itemVariants} className="col-md-6 mb-4">
                    <label className="form-label fw-semibold">
                      <FaMoneyBillWave className="me-2" />
                      Price (₹)
                    </label>
                    <input
                      type="number"
                      className="form-control form-control-lg border-2 py-3"
                      name="price"
                      value={book.price}
                      onChange={handleChange}
                      min="0"
                      step="0.01"
                      placeholder="0.00"
                      required
                    />
                  </motion.div>
                </div>

                {/* Pages */}
                <motion.div variants={itemVariants} className="mb-4">
                  <label className="form-label fw-semibold">
                    <FaFileAlt className="me-2" />
                    Number of Pages
                  </label>
                  <input
                    type="number"
                    className="form-control form-control-lg border-2 py-3"
                    name="pages"
                    value={book.pages}
                    onChange={handleChange}
                    min="1"
                    placeholder="Enter page count"
                    required
                  />
                </motion.div>

                {/* Description */}
                <motion.div variants={itemVariants} className="mb-4">
                  <label className="form-label fw-semibold">
                    <FaFileAlt className="me-2" />
                    Description
                  </label>
                  <textarea
                    className="form-control form-control-lg border-2"
                    rows="4"
                    name="description"
                    value={book.description}
                    onChange={handleChange}
                    placeholder="Enter book description..."
                    required
                  />
                </motion.div>

                <motion.div
                  variants={itemVariants}
                  className="d-grid mt-4"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <button
                    type="submit"
                    className="btn btn-primary btn-lg rounded-pill py-3 fw-bold"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                        Adding Book...
                      </>
                    ) : (
                      <>
                        <FaPlusCircle className="me-2" />
                        Add Book
                      </>
                    )}
                  </button>
                </motion.div>
              </motion.form>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default AddBook;