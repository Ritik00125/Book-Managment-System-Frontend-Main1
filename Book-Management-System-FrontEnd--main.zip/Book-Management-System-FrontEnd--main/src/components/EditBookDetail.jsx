import React, { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import { useNavigate, useParams } from "react-router-dom";
import toast, { Toaster } from "react-hot-toast";
import Swal from "sweetalert2";

const EditBookDetail = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const [book, setBook] = useState({
    name: "",
    author: "",
    edition: "",
    price: "",
    pages: "",
    description: "",
  });
 

  //get book by the id

  useEffect(() => {
    const getBookBYId = async () => {
      try {
        const responce = await axios.get(
          `http://localhost:4000/get-book-by-id/${id}`
        );

        // setBook((prev) => ({
        //   ...prev,
        //   name: responce.data.name,
        //   author: responce.data.author,
        //   edition: responce.data.edition,
        //   price: responce.data.price,
        //   pages: responce.data.pages,
        //   description: responce.data.description,
        // }));
        setBook(responce.data.data)
      } catch (error) {
        console.log(error);
      }
    };
    //getBooks();
    getBookBYId();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setBook((prev) => ({ ...prev, [name]: value }));
  };

  //update the book details
  const handleSubmit = async (e) => {
    e.preventDefault();

    const result = await Swal.fire({
      title: "Are you sure?",
      text: "Do you want to update this book's details?",
      icon: "question",
      showCancelButton: true,
      confirmButtonText: "Yes, update it!",
      cancelButtonText: "Cancel",
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#aaa",
    });
    if (result.isConfirmed) {
      try {
        await axios.put(`http://localhost:4000/update-book-detail/${id}`, book);
        Swal.fire({
          title: "Updated!",
          text: "Book details have been updated successfully.",
          icon: "success",
          timer: 2000,
          showConfirmButton: false,
        });
        navigate("/book-list")
      } catch (error) {
        console.log(error);
          Swal.fire({
        title: 'Error!',
        text: 'Something went wrong while updating.',
        icon: 'error'
      });
      }
      // Here you can add your logic to POST data to server or update JSON
      toast("Book Detail  updated successfully ");
    }
  };
  return (
    <div className="container mt-5">
      <Toaster />
      <div className="card shadow-lg">
        <div className="card-header bg-primary text-white">
          <h3 className="mb-0">Add New Book</h3>
        </div>
        <div className="card-body">
          <form onSubmit={handleSubmit}>
            {/* Book Name */}
            <div className="mb-3">
              <label className="form-label">Book Name</label>
              <input
                type="text"
                className="form-control"
                name="name"
                value={book.name || ""}
                onChange={handleChange}
                required
              />
            </div>

            {/* Author Name */}
            <div className="mb-3">
              <label className="form-label">Author Name</label>
              <input
                type="text"
                className="form-control"
                name="author"
                value={book.author || ""}
                onChange={handleChange}
                required
              />
            </div>

            {/* Edition */}
            <div className="mb-3">
              <label className="form-label">Edition</label>
              <input
                type="text"
                className="form-control"
                name="edition"
                value={book.edition || ""}
                onChange={handleChange}
                required
              />
            </div>

            {/* Price */}
            <div className="mb-3">
              <label className="form-label">Price (₹)</label>
              <input
                type="number"
                className="form-control"
                name="price"
                value={book.price || ""}
                onChange={handleChange}
                min="0"
                required
              />
            </div>

            {/* Pages */}
            <div className="mb-3">
              <label className="form-label">Number of Pages</label>
              <input
                type="number"
                className="form-control"
                name="pages"
                value={book.pages || ""}
                onChange={handleChange}
                min="1"
                required
              />
            </div>

            {/* Description */}
            <div className="mb-3">
              <label className="form-label">Description</label>
              <textarea
                className="form-control"
                rows="3"
                name="description"
                value={book.description || ""}
                onChange={handleChange}
                required
              />
            </div>

            <button type="submit" className="btn btn-success w-50 m-auto">
              Update Book Detail
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default EditBookDetail;
