import React, { useEffect, useState } from "react";
import axios from "axios";

const AllUsers = () => {
  const [users, setUsers] = useState([]);

  // Fetch all users on mount
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await axios.get("http://localhost:4000/get-all-user");
        console.log(res)
        setUsers(res.data.user);
      } catch (err) {
        console.error("Error fetching users:", err);
      }
    };

    fetchUsers();
  }, []);

  const handleEdit = (userId) => {
    alert(`Edit user ID: ${userId}`);
    // Navigate or open modal etc.
  };

  const handleDelete = async (userId) => {
    // if (window.confirm("Are you sure you want to delete this user?")) {
    //   try {
    //     await axios.delete(`http://localhost:4000/users/${userId}`);
    //     setUsers(users.filter((user) => user._id !== userId));
    //     alert("User deleted successfully.");
    //   } catch (error) {
    //     console.error("Delete failed:", error);
    //     alert("Error deleting user.");
    //   }
    // }
  };

  return (
    <div className="container my-4">
      <h2 className="text-center mb-4">All Users</h2>
      <div className="row">
        {users.map((user) => (
          <div className="col-md-6 col-lg-4 mb-4" key={user._id}>
            <div className="card shadow-sm h-100">
              <img
                src={ "https://www.hindustantimes.com/ht-img/img/2025/06/02/550x309/Cricket-Virat-Kohli-0_1748840730416_1748840743207.jpg"}
                alt="Profile"
                className="card-img-top object-fit-cover"
                style={{ height: "250px", objectFit: "cover" }}
              />
              <div className="card-body">
                <h5 className="card-title fw-bold">{user.fullName}</h5>
                <p className="card-text">
                  <strong>Email:</strong> {user.email} <br />
                  <strong>Username:</strong> {user.username} <br />
                  <strong>Mobile:</strong> {user.mobileNumber} <br />
                  <strong>Address:</strong> {user.address}
                </p>
                <div className="d-flex justify-content-between">
                  <button
                    className="btn btn-primary btn-sm"
                    onClick={() => handleEdit(user._id)}
                  >
                    Edit
                  </button>
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => handleDelete(user._id)}
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
        {users.length === 0 && (
          <div className="text-center mt-5">
            <p className="text-muted">No users found.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AllUsers;
